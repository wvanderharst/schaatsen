# Schaatsmodel — rating, piektijden en race-simulatie (langebaan)

## Starten
1. Zet de data naast de code: `speedskating_historie_racedatum.csv` (nieuw, met `Race_Datum` per afstand; ook de oude `speedskating_historie_clean.csv` werkt).
2. `pip install numpy pandas scipy numba pyarrow pytest requests beautifulsoup4`
3. Model bouwen (≈1 uur, ~6 GB): `./bouw_model.sh` → `model_full_tuned.pkl` (+ `.extra`), `normaal_z*.pkl`, `hist_nieuw.npz`.
   De gebouwde modelbestanden zitten **niet** in deze zip (≈2 GB); ze zijn met dit script opnieuw te maken.
4. Webpagina: `python export_web.py` → `web_model.json`; daarna `python bouw_pagina.py`. `web/langebaan.html` is de laatst gepubliceerde versie.
   Let op: `VANDAAG` staat vast in `export_web.py` (2026-10-03).
5. Tests: `pytest test_model.py -q` (klein, op `speedskating_test.csv`); `--volledig` voor de volledige database (alleen op verzoek).

## Opbouw van het model (`do_analysis.py`)
- **Toestand per rijder × afstand**: x = ln(T − T_lim), EKF met GARCH op de waarneming-ruis (s), procesruis per groep, correlatie tussen afstanden.
  Mengsels in de update: slechte dag (dip), **niveausprong** aan de snelle kant (sprongkans 2%, variantie 25·S) met **eigen sprongkans per rijder** (`sprong_m=50`, lang geheugen), kortetermijn-vorm als OU-proces.
- **Dag-effect** θ per event × geslacht × afstand, met baan-prior.
- **Lagen alleen op de voorspelling** (geschat in `kalibreer`, volgorde): trend/verrassingen (o.a. `cx`: vorige afstand zelfde toernooi), `loc_schaal` (per geslacht × afstand × niveau), piekkans per rijder (3 gebieden), GAS (score-gedreven, rijder kort + rijder × afstand lang, scheve score), `vol_asym` (snelle kant schaalt met relatieve volatiliteit^0,8), **vormtoestand op dag-z** (kort 7 d, uitschieters 60 d, staartkalibratie γ·√N), **ijs per niveau** (alleen dag-relatief: (ijs−HV)·k(niveau) + hoogland·h(niveau)), **piekdiepte per rijder** (τ, 4 jaar geheugen, m=20, κ=1,5).
- Normaal-equivalente z: `normaal_z` (vooraf) en `normaal_z_dag` (t.o.v. het veld) — de pagina toont de dag-z.
- `voorspel` / `Historie.voorspel` geven o.a. `normale_tijd`, `piek_tijd`, `normale_basis` (vaste rating zonder tijdelijke vorm), `snel_fac`, `piek_diepte`.

## Belangrijkste resultaten (eerlijke log loss, 2020+)
| stap | effect |
|---|---|
| loc_schaal | −0,015 (top 2%: −0,042) |
| piekkans per rijder | −0,005 |
| GAS-laag | −0,014 |
| vol_asym | −0,003 |
| piekdiepte | −0,0004 vooraf, −0,0006 dag (elite dag −0,004) |
| eigen sprongkans (m=50) | −0,0015 (elite −0,0023) |
| getest en verworpen | adaptieve procesruis per rijder (+0,0003…+0,0014), sprongen aan de trage kant, langzamere vorm-uitdoving |

Seizoensbeste onder de 5%-lijn (hoort 5%): elite 2010–19 van 15% naar 9%; vanaf 2020 nog 20% → zie open punten.

## Onderzoek vorm en vermoeidheid (oktober 2026, `onderzoek/vorm_vermoeidheid*.py`)
Met de nieuwe racedatums; verrassing t.o.v. de verwachting vóór het toernooi én t.o.v. het veld in dezelfde race; zelfde dag: kortste afstand eerst.

**Vorm (helling van verrassing race 2 op race 1, zelfde toernooi):** zelfde dag 0,49 · 1 dag 0,46 · 2 dagen 0,41 · 3–4 dagen 0,37 · 5–9 dagen 0,40 (toppers/elite gelijk). Binnen meerkampen dag 1 → dag 2: sprint 0,67, klein allround 0,56, groot allround 0,59, junior allround 0,68.
→ De verrassing houdt binnen een toernooi grotendeels stand en neemt in een week maar langzaam af (≈0,49 → 0,40). Ondersteunt "vorm blijft ~5 dagen". Deels is dit blijvende ratingfout; het tijdelijke deel is ≈0,1.

**Vermoeidheid t.o.v. het veld (toppers, verrassing in sd, + = trager; basis zonder eerdere race ≈ +0,13):** 1000 m na een 1500 m dezelfde dag +0,64; 3000 m na een 1500 m +0,40; 5000 m na een kortere race +0,37…+0,43. De dag erna: klein (+0,1 op de 500 m na >5 km).

**Vermoeidheid in meerkampen (hele veld; dag-effect t.o.v. dezelfde afstand in losse races, % van de tijd):** vooral de lange slotafstand is trager: groot allround 10.000 m +0,36%, klein allround 5000 m dag 2 +0,25%, junior allround 3000 m dag 2 +0,17%. Sprint dag 2 ≈ dag 1.

## Open punten / volgende stappen
1. **Model herbouwen op `speedskating_historie_racedatum.csv`**: `laad_dataset` splitst toernooien dan per dag (event_id + 1.000.000·dag-offset; `toernooi_id` bewaart het origineel). Daarna eerlijke log loss vergelijken en de dag-relatieve lagen (ijs per niveau, vorm) opnieuw schatten.
2. **Vorm en vermoeidheid in het model** op basis van bovenstaande: vorm binnen toernooi meenemen over dagen (plateau ~5 dagen toetsen), vermoeidheidsterm (eerder gereden meters dezelfde dag / slotafstand meerkamp).
3. Staart sinds 2019 dikker voor toppers (seizoensbeste 2020+ te vaak extreem): vorm van de dag-verdeling op een rollend venster schatten.
4. Piektijd herdefiniëren als verwachte seizoensbeste.
5. Twee tests falen nipt sinds de sprongkans per rijder (historie-spreiding 0,00012 > 0,0001; Leerdam 1500 m in het 5%-testmodel).

## Mappen
- `scraper/`: `scraper_schaatsen.py` (racedatum per afstand, slaat ploegen/massastart over, herkansingen), `ssr_racedatums.py` + `backfill.py` (bestaande CSV bijwerken).
- `onderzoek/`: labscripts van de recente stappen (verwijzen soms naar tussenbestanden uit de cloud-sessie, bv. `gas_d.pkl`, `zbase.pkl`; die moet je eerst opnieuw maken).
- `data_hulp/`: uitgesloten races, vermoedelijke datafouten, eventnamen.
